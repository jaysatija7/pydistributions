from setuptools import setup

setup(name='pydistributions',
      version='1.0.0',
      description='Gaussian and Binomial Distributions',
      packages=['pydistributions'],
      author='Jay Satija',
      author_email='jaysatija712@gmail.com',
      zip_safe=False)
